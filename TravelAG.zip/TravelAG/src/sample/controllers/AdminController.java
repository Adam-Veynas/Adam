package sample.controllers;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import sample.Main;
import sample.db.DBManager;
import sample.entites.Tour;
import sample.entites.User;

public class AdminController implements Initializable {
    private static Tour tour;


    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableView<Tour> table;

    @FXML
    private TableColumn<Tour, Integer> idColumn;

    @FXML
    private TableColumn<Tour, String> FirstCityColumn;

    @FXML
    private TableColumn<Tour, String> SecondCityColumn;

    @FXML
    private TableColumn<Tour, Integer> daysColumn;

    @FXML
    private TableColumn<Tour, Integer> priceColumn;
    @FXML
    private TextField FirstCityField;

    @FXML
    private TextField SecondCityField;

    @FXML
    private TextField daysField;

    @FXML
    private TextField priceField;

    @FXML
    private Button addButton;

    @FXML
    private Button deleteButton;

    @FXML
    private Label logoutLabel;

    @FXML
    private CheckBox HotelCheckbox;

    @FXML
    private TextArea descriptionField;

    @FXML
    private ImageView chat;

    @FXML
    private TextField Search;

    ObservableList<Tour> oblist = FXCollections.observableArrayList();
    private DBManager dbm;

    @FXML
    void logout(MouseEvent event) {
        logoutLabel.getScene().getWindow().hide();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/sample/views/signin.fxml"));
        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Parent root = loader.getRoot();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
        Main.user=null;
    }

    @FXML
    void select(MouseEvent event) {
        try {
            tour = table.getSelectionModel().getSelectedItem();
            descriptionField.setText(tour.getDescription());
        }catch (Exception e){

        }
    }

    @FXML
    void initialize() { }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        oblist=(ObservableList<Tour>) DBManager.getTours();
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        FirstCityColumn.setCellValueFactory(new PropertyValueFactory<>("f_city"));
        SecondCityColumn.setCellValueFactory(new PropertyValueFactory<>("s_city"));
        daysColumn.setCellValueFactory(new PropertyValueFactory<>("days"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("t_price"));
        table.setItems(oblist);
        deleteButton.setOnAction(event ->{
                DBManager.deleteTour(tour);
                showAllTour();
        });
        addButton.setOnAction(event ->{
          String f_city=FirstCityField.getText();
            String s_city=SecondCityField.getText();
            int days=Integer.parseInt(daysField.getText());
            int price=Integer.parseInt(priceField.getText());
            String descript = descriptionField.getText();
            DBManager.addTour(new Tour(null,f_city,s_city,days,price,descript));
            showAllTour();
        });

    }

    private void showAllTour() {
        oblist.clear();
        oblist=(ObservableList<Tour>) DBManager.getTours();
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        FirstCityColumn.setCellValueFactory(new PropertyValueFactory<>("f_city"));
        SecondCityColumn.setCellValueFactory(new PropertyValueFactory<>("s_city"));
        daysColumn.setCellValueFactory(new PropertyValueFactory<>("days"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("t_price"));
        table.setItems(oblist);
    }
}
