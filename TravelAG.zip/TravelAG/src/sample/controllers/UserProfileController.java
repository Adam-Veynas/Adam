package sample.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import sample.Main;
import sample.db.DBManager;
import sample.entites.Tour;

public class UserProfileController implements Initializable {

    private static Tour tour;

    @FXML
    private TextArea descriptionField;

    @FXML
    private Button deleteButton;

    @FXML
    private Label backLabel;

    @FXML
    private TextField fullName;

    @FXML
    private TextField login;

    @FXML
    private TableView<Tour> table;

    @FXML
    private TableColumn<Tour, Integer> idColumn;

    @FXML
    private TableColumn<Tour, String> FirstCityColumn;

    @FXML
    private TableColumn<Tour, String> SecondCityColumn;

    @FXML
    private TableColumn<Tour, Integer> daysColumn;

    @FXML
    private TableColumn<Tour, Integer> priceColumn;

    @FXML
    void back(MouseEvent event) {
        backLabel.getScene().getWindow().hide();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/sample/views/profile.fxml"));
        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Parent root = loader.getRoot();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    void delete(ActionEvent event) {
        DBManager.deleteTourtoUser(Main.user,tour);
        refresh();
    }

    @FXML
    void select(MouseEvent event) {
        try {
            tour = table.getSelectionModel().getSelectedItem();
            descriptionField.setText(tour.getDescription());
        }catch (Exception e){

        }
    }

    @FXML
    void initialize() { }

    ObservableList<Tour> oblist= FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        fullName.setText(Main.user.getFirst_name()+" "+Main.user.getSecond_name());
        login.setText(Main.user.getLogin());
        oblist=(ObservableList<Tour>)DBManager.getUserTours(Main.user);
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        FirstCityColumn.setCellValueFactory(new PropertyValueFactory<>("f_city"));
        SecondCityColumn.setCellValueFactory(new PropertyValueFactory<>("s_city"));
        daysColumn.setCellValueFactory(new PropertyValueFactory<>("days"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("t_price"));

        table.setItems(oblist);

        deleteButton.setOnAction(actionEvent -> {
            DBManager.deleteTourtoUser(Main.user,tour);
            refresh();
        });
    }

    private void refresh(){
        oblist.clear();
        oblist=(ObservableList<Tour>) DBManager.getUserTours(Main.user);
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        FirstCityColumn.setCellValueFactory(new PropertyValueFactory<>("f_city"));
        SecondCityColumn.setCellValueFactory(new PropertyValueFactory<>("s_city"));
        daysColumn.setCellValueFactory(new PropertyValueFactory<>("days"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("t_price"));
        table.setItems(oblist);
    }
}
