package sample.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import sample.Main;
import sample.db.DBManager;
import sample.entites.Tour;

public class ProfileController implements Initializable {

    private static Tour tour;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button buyButton;

    @FXML
    private Label logoutLabel;

    @FXML
    private Text Profile;

    @FXML
    private TableView<Tour> table;

    @FXML
    private TableColumn<Tour, Integer> idColumn;

    @FXML
    private TableColumn<Tour, String> FirstCityColumn;

    @FXML
    private TableColumn<Tour, String> SecondCityColumn;

    @FXML
    private TableColumn<Tour, Integer> daysColumn;

    @FXML
    private TableColumn<Tour, Integer> priceColumn;

    @FXML
    private TextArea descriptionField;

    @FXML
    private TextField fullName;

    @FXML
    private TextField login;

    @FXML
    private ImageView chat;

    @FXML
    void logout(MouseEvent event) {
        logoutLabel.getScene().getWindow().hide();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/sample/views/signin.fxml"));
        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Parent root = loader.getRoot();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
        Main.user=null;
    }

    @FXML
    void profile(MouseEvent event) {
        logoutLabel.getScene().getWindow().hide();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/sample/views/userprofile.fxml"));
        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Parent root = loader.getRoot();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    void select(MouseEvent event) {
        try {
            tour = table.getSelectionModel().getSelectedItem();
            descriptionField.setText(tour.getDescription());
        }catch (Exception e){

        }
    }

    @FXML
    void initialize() { }

    ObservableList<Tour> oblist= FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        fullName.setText(Main.user.getFirst_name()+" "+Main.user.getSecond_name());
        login.setText(Main.user.getLogin());
        oblist=(ObservableList<Tour>) DBManager.getTours();
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        FirstCityColumn.setCellValueFactory(new PropertyValueFactory<>("f_city"));
        SecondCityColumn.setCellValueFactory(new PropertyValueFactory<>("s_city"));
        daysColumn.setCellValueFactory(new PropertyValueFactory<>("days"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("t_price"));
        table.setItems(oblist);
        buyButton.setOnAction(event -> {
            DBManager.addTourToUser(Main.user,tour);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Thanks for used our service");
            alert.setHeaderText(null);
            alert.setContentText("Tour successfully bought!");
            alert.showAndWait();
            refresh();
        });
    }

    @FXML
    void openchat(MouseEvent event) {
        try{
            Stage stage=new Stage();
            Parent root=FXMLLoader.load(getClass().getResource("/sample/views/chat.fxml"));
            stage.setScene(new Scene(root));
            stage.setTitle("Chat");
            stage.setMinHeight(200);
            stage.setMinWidth(300);
            stage.setResizable(true);
            stage.initModality(Modality.WINDOW_MODAL);
            stage.show();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    private void refresh(){
        oblist.clear();
        oblist=(ObservableList<Tour>) DBManager.getTours();
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        FirstCityColumn.setCellValueFactory(new PropertyValueFactory<>("f_city"));
        SecondCityColumn.setCellValueFactory(new PropertyValueFactory<>("s_city"));
        daysColumn.setCellValueFactory(new PropertyValueFactory<>("days"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("t_price"));
        table.setItems(oblist);
    }

    public void buy(ActionEvent actionEvent) {
    }
}
