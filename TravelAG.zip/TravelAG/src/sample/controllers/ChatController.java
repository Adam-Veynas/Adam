package sample.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

//import com.sun.javaws.jnl.JavaFXRuntimeDesc;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.fxml.JavaFXBuilderFactory;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import sample.Main;
import sample.network.TCPConnection;
import sample.network.TCPConnectionListener;

public class ChatController implements TCPConnectionListener, Initializable {

    private TCPConnection connection;

    public ChatController() {
        try {
            connection=new TCPConnection(this,"localhost",8000);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextArea chatArea;

    @FXML
    private TextField usernameField;

    @FXML
    private TextField messageField;

    @FXML
    private Button send;

    @FXML
    void send(ActionEvent event) {
        String message=messageField.getText();
        String username=usernameField.getText();
        connection.sendString(username+" :"+message);
    }

    @FXML
    void sendEnter(KeyEvent event) { }

    @FXML
    void initialize() { }

    @Override
    public void onConnectionReady(TCPConnection tcpConnection) {
        printMsg("Connection ready...");
    }

    @Override
    public void onReceiveString(TCPConnection tcpConnection, String value) {
        printMsg(value);
    }

    @Override
    public void onDisconnect(TCPConnection tcpConnection) {
        printMsg("disconnected...");
    }

    @Override
    public void onException(TCPConnection tcpConnection, Exception e) {

    }

    private synchronized void printMsg(String value){
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                chatArea.appendText(value+"\n");
            }
        });
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        usernameField.setText(Main.user.getFirst_name());
    }
}
