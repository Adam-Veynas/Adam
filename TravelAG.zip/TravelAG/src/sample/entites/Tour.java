package sample.entites;
import java.io.Serializable;
public class Tour implements Serializable {
    private Long id;
    private String f_city;
    private String s_city;
    private int days;
    private int t_price;
    private String description;

    public Tour(Long id, String f_city, String s_city, int days, int t_price, String description) {
        this.id = id;
        this.f_city = f_city;
        this.s_city = s_city;
        this.days = days;
        this.t_price = t_price;
        this.description = description;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getF_city() {
        return f_city;
    }

    public void setF_city(String f_city) {
        this.f_city = f_city;
    }

    public String getS_city() {
        return s_city;
    }

    public void setS_city(String s_city) {
        this.s_city = s_city;
    }

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public int getT_price() {
        return t_price;
    }

    public void setT_price(int t_price) {
        this.t_price = t_price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
