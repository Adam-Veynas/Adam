package sample.db;
import javafx.collections.FXCollections;
import sample.entites.Tour;
import sample.entites.User;
import java.sql.*;
import java.util.List;
public class DBManager {
    public static Connection connect() throws SQLException {

        try {
            Connection connection;
            String userName= "root";
            String password = "";
            connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/ta?useUnicode=true&serverTimezone=UTC", "root", "");
            Class.forName("com.mysql.cj.jdbc.Driver");
            return connection;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
    public static void addUser(User user){
        try{
            String sqlText="INSERT INTO userss (id, first_name, second_name, login, password, checku) VALUES (NULL,?,?,?,?,false)";
            PreparedStatement statement=connect().prepareStatement(sqlText);
            statement.setString(1,user.getFirst_name());
            statement.setString(2,user.getSecond_name());
            statement.setString(3,user.getLogin());
            statement.setString(4,user.getPassword());
            statement.executeUpdate();
            statement.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public static User getUser(String login, String password) {
        User user = null;
        try {

            PreparedStatement ps = connect().prepareStatement("SELECT * FROM userss WHERE login=? AND password=?");
            ps.setString(1, login);
            ps.setString(2,password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                user = new User(rs.getLong("id"),
                        rs.getString("first_name"),
                        rs.getString("second_name"),
                        rs.getString("login"),
                        rs.getString("password"),
                        rs.getBoolean("checku"));
            }
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }
    public static User getUser(String login) {
        User user = null;
        try {

            PreparedStatement ps = connect().prepareStatement("SELECT * FROM userss WHERE login=?");
            ps.setString(1, login);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                user = new User(
                        rs.getLong("id"),
                        rs.getString("first_name"),
                        rs.getString("second_name"),
                        rs.getString("login"),
                        rs.getString("password"),
                        rs.getBoolean("checku"));
            }
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }

    public static Tour getTour(Long id) {
        Tour tour = null;
        try{
            PreparedStatement ps=connect().prepareStatement("SELECT * FROM tours WHERE id=?");
            ps.setLong(1,id);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                tour=new Tour(
                      rs.getLong("id"),
                        rs.getString("f_city"),
                        rs.getString("s_city"),
                        rs.getInt("days"),
                        rs.getInt("t_price"),
                        rs.getString("description"));
            }
            ps.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return tour;
    }

    public static Tour getMyTour(Long id,Long userId) {
        Tour tour=null;
        try{
            PreparedStatement ps=connect().prepareStatement(
                    "SELECT ut.id, ut.tour_id, ut.user_id, t.id, t.f_city, t.s_city, t.days, t.t_price, t.description" +
                         "FROM user_tour ut " +
                            "LEFT OUTER JOIN tours t ON ut.tour_id=t.id" +
                            " WHERE user_id=? AND tour_id=?");
            ps.setLong(1,userId);
            ps.setLong(2,id);

            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                tour=new Tour(
                        rs.getLong("id"),
                        rs.getString("f_city"),
                        rs.getString("s_city"),
                        rs.getInt("days"),
                        rs.getInt("t_price"),
                        rs.getString("description"));
            }
            ps.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return tour;
    }


    public static void addTour(Tour tour){
        try{
            PreparedStatement statement=connect().prepareStatement(
                    "INSERT INTO tours (id, f_city, s_city, days, t_price, description) VALUES (NULL,?,?,?,?,?)"
            );
          statement.setString(1,tour.getF_city());
          statement.setString(2,tour.getS_city());
          statement.setInt(3,tour.getDays());
          statement.setInt(4,tour.getT_price());
          statement.setString(5,tour.getDescription());
            statement.executeUpdate();
            statement.close();
        }catch (Exception e){

        }
    }
    public static List<Tour> getTours(){
        List<Tour> tours = FXCollections.observableArrayList();;
        try{
            PreparedStatement pr=connect().prepareStatement(
                    "SELECT * FROM tours"
            );
            ResultSet rs=pr.executeQuery();
            while (rs.next()){
                tours.add(new Tour(
                        rs.getLong("id"),
                        rs.getString("f_city"),
                        rs.getString("s_city"),
                        rs.getInt("days"),
                        rs.getInt("t_price"),
                        rs.getString("description")));
            }
            pr.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return tours;
    }

    public static List<Tour> getUserTours(User user){
        List<Tour> tours=FXCollections.observableArrayList();;
        Tour tour = null;
        try{
            PreparedStatement pr=connect().prepareStatement(
                    "SELECT  ut.user_id, ut.tour_id, t.id, t.f_city, t.s_city, t.days, t.t_price, t.description " +
                            "FROM user_tour ut " +
                            "LEFT OUTER JOIN tours t ON ut.tour_id=t.id" +
                            " WHERE user_id=?"
            );
            pr.setLong(1,user.getId());
            ResultSet rs=pr.executeQuery();

            while(rs.next()){
                tour=new Tour(
                        rs.getLong("id"),
                        rs.getString("f_city"),
                        rs.getString("s_city"),
                        rs.getInt("days"),
                        rs.getInt("t_price"),
                        rs.getString("description"));
                tours.add(tour);
            }
            pr.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return tours;
    }

    public static void deleteTour(Tour tour) {
        try {
            PreparedStatement statement=connect().prepareStatement(
                    "DELETE FROM tours WHERE id=?"
            );
            statement.setLong(1,tour.getId());
            statement.executeUpdate();
            statement.close();
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public static void deleteTourtoUser(User user,Tour tour){
        try{
            PreparedStatement statement=connect().prepareStatement(
                    "DELETE FROM user_tour WHERE id=? LIMIT 1"
            );
            statement.setLong(1, tour.getId());
            statement.executeUpdate();
            statement.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void addTourToUser(User user, Tour tour) {
        try{
            PreparedStatement statement=connect().prepareStatement(
                    "INSERT INTO user_tours (user_id, tour_id) VALUES (?,?)"
            );
            statement.setLong(1,user.getId());
            statement.setLong(2,tour.getId());
            statement.executeUpdate();
            statement.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
